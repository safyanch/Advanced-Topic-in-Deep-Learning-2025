from langchain_openai import OpenAIEmbeddings
from dotenv import load_dotenv
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

load_dotenv()

embedding = OpenAIEmbeddings(model='text-embedding-3-large', dimensions=300)

documents = [
"Inzamam-ul-Haq was a dependable middle-order batsman known for his calm temperament and match-winning knocks.",
"Saeed Anwar was a graceful opener admired for his elegant timing and high-scoring innings.",
"Wasim Akram, the 'Sultan of Swing', is celebrated for his mastery of fast bowling and reverse swing.",
"Shoaib Akhtar, known as the 'Rawalpindi Express', was the fastest bowler in cricket history with blistering pace.",

]

query = 'tell me about shoaib akthar'

doc_embeddings = embedding.embed_documents(documents)
query_embedding = embedding.embed_query(query)
#print(cosine_similarity([query_embedding], doc_embeddings))
scores = cosine_similarity([query_embedding], doc_embeddings)[0]
#print(list(enumerate(scores)))
#print(sorted(list(enumerate(scores)), key=lambda x:x[1]))
#print(sorted(list(enumerate(scores)), key=lambda x:x[1])[-1])
index, score = sorted(list(enumerate(scores)),key=lambda x:x[1])[-1]

print(query)
print(documents[index])
print("similarity score is:", score)




