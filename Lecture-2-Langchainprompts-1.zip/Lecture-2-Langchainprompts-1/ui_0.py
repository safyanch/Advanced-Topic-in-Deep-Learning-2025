from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import streamlit as st
from langchain_core.prompts import PromptTemplate,load_prompt

load_dotenv()


st.header('Reasearch Tool')
user_input=st.text_input('enter your prompt')

if st.button('Summarize'):
    st.text('some random input')